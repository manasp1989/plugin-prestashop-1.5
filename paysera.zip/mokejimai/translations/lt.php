<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{mokejimai}prestashop>configuration_3f86574ad34d16a8cf2ba530c9aafee7'] = 'Šis modulis leidžia priimti mokėjimus per Mokėjimai.lt sistemą.';
$_MODULE['<{mokejimai}prestashop>configuration_b6af2d31afe71aedcceca73cc27fec29'] = 'Jeigu klientas pasirinks šį mokėjimo būdą, užsakymas pakeis savo būklę į \"Laukiama\" apmokėjimo';
$_MODULE['<{mokejimai}prestashop>configuration_aa9f04d1be872e3bdaca1cccf7f02d12'] = 'Mokėjimo modulio nustatymai';
$_MODULE['<{mokejimai}prestashop>configuration_f5f04b11870f0822cfc263fdc6214528'] = 'Įrašykite mokėjimai.lt modulio duomenis.';
$_MODULE['<{mokejimai}prestashop>configuration_25f59120d6dfe355c2aeaf4e7cd3a351'] = 'Mokėjimai.lt vartotojo ID:';
$_MODULE['<{mokejimai}prestashop>configuration_bad256fc73f1c0dd9f2a52a75078de3b'] = 'Mokėjimai.lt projekto ID:';
$_MODULE['<{mokejimai}prestashop>configuration_ae71d10996c375bccc46d24665b318a9'] = 'Mokėjimai.lt projekto slaptažodis:';
$_MODULE['<{mokejimai}prestashop>configuration_2f1120281bc59dbf84f4b7d9f210b421'] = 'Testinis režimas?';
$_MODULE['<{mokejimai}prestashop>configuration_93cba07454f06a4a960172bbd6e2a435'] = 'Taip';
$_MODULE['<{mokejimai}prestashop>configuration_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Ne';
$_MODULE['<{mokejimai}prestashop>configuration_2f8251979372d44fa8e3df67202cbef1'] = 'Rodyti mokėjimo būdų pasirinkimą?';
$_MODULE['<{mokejimai}prestashop>configuration_49b80feb114d68c0b124c0129536bd02'] = 'Pradinė mokėjimo būdų pasirinkimo šalis';
$_MODULE['<{mokejimai}prestashop>configuration_b17f3f4dcf653a5776792498a9b44d6a'] = 'Atnaujinti nustatymus';
