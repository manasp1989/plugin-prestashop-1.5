<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{mokejimai}prestashop>configuration_3f86574ad34d16a8cf2ba530c9aafee7'] = 'This module allows you to accept payments by Paysera.com';
$_MODULE['<{mokejimai}prestashop>configuration_b6af2d31afe71aedcceca73cc27fec29'] = 'If the client chooses this payment mode, the order will change its status into a \'Waiting for payment\' status.';
$_MODULE['<{mokejimai}prestashop>configuration_aa9f04d1be872e3bdaca1cccf7f02d12'] = 'Payment module details';
$_MODULE['<{mokejimai}prestashop>configuration_f5f04b11870f0822cfc263fdc6214528'] = 'Please specify the Paysera.com details';
$_MODULE['<{mokejimai}prestashop>configuration_bad256fc73f1c0dd9f2a52a75078de3b'] = 'Paysera.com project ID:';
$_MODULE['<{mokejimai}prestashop>configuration_ae71d10996c375bccc46d24665b318a9'] = 'Paysera.com project passaword:';
$_MODULE['<{mokejimai}prestashop>configuration_2f1120281bc59dbf84f4b7d9f210b421'] = 'Test mode:';
$_MODULE['<{mokejimai}prestashop>configuration_93cba07454f06a4a960172bbd6e2a435'] = 'Yes';
$_MODULE['<{mokejimai}prestashop>configuration_bafd7322c6e97d25b6299b5d6fe8920b'] = 'No';
$_MODULE['<{mokejimai}prestashop>configuration_2f8251979372d44fa8e3df67202cbef1'] = 'Display payments list:';
$_MODULE['<{mokejimai}prestashop>configuration_49b80feb114d68c0b124c0129536bd02'] = 'Default payment country:';
$_MODULE['<{mokejimai}prestashop>configuration_b17f3f4dcf653a5776792498a9b44d6a'] = 'Update settings';
